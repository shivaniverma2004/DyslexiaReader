import SwiftUI

struct ContentView: View {
    @State private var selectedImages: [UIImage] = []
    @State private var navigateToPreview = false
    @State private var showActionSheet = false
    @State private var showNamePrompt = false
    @ObservedObject private var projectManager = ProjectManager.shared
    @State private var isCameraPresented = false
    @State private var isImagePickerPresented = false
    @State private var showProjectView = false
    @State private var showWordBasketView = false
    @State private var selectedProject: String?
    @State private var navigateToProject = false
    @State private var imagesInSelectedProject: [UIImage] = []
    @State private var selectedWord: String = ""
    @State private var showPronunciationPractice = false
    @State private var points: Int = ProjectManager.shared.points
    @State var fontName = "OpenDyslexic"
    

    var body: some View {
        NavigationStack {
            VStack {
                // Header with greeting and points
                HStack {
                    HStack {
                        Image(systemName: "star.fill")
                            .foregroundColor(.yellow)
                        Text("\(projectManager.points)")
                            .font(.custom(fontName, size: 22))
                            .foregroundColor(.black) // High contrast text color
                    }
                    .padding(8)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(20)
                    Spacer()
                    Text("Hi, \(projectManager.userName)")
                        .font(.custom(fontName, size: 24))
                        .foregroundColor(.black) // High contrast text color
                    Spacer()
                    Button(action: { showActionSheet = true }) {
                        Image(systemName: "plus")
                            .resizable()
                            .frame(width: 22, height: 22)
                            .padding(8)
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(20)
                    }
                }
                .padding()
                

                // Main content
                ScrollView {
                    VStack(spacing: 16) {
                        // Projects Section
                        VStack(alignment: .leading) {
                            HStack {
                                Image(systemName: "folder.fill") // Folder icon
                                    //.foregroundColor(.blue)
                                Text("Projects")
                                    .font(.custom(fontName, size: 24))
                                    .foregroundColor(.black) // High contrast text color
                                Spacer()
                                NavigationLink(destination: ProjectsView(points: $points)) {
                                    Text("See All")
                                        .font(.custom(fontName, size: 18))
                                        .foregroundColor(.blue)
                                }
                            }
                            .padding([.leading, .trailing])

                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 16) {
                                    ForEach(projectManager.projectNames, id: \.self) { project in
                                        if let firstImage = projectManager.getImages(for: project).first {
                                            ProjectPreviewCard(projectName: project, image: firstImage)
                                                .frame(width: 170, height: 200)
                                                .onTapGesture {
                                                    openProject(named: project)
                                                }
                                        } else {
                                            ProjectPreviewCard(projectName: project, image: UIImage())
                                                .frame(width: 170, height: 200)
                                                .onTapGesture {
                                                    openProject(named: project)
                                                }
                                        }
                                    }
                                }
                                .padding([.leading, .trailing, .bottom])
                            }
                        }
                        .padding(.top)

                        Divider()

                        // Word Basket Section (USING `WordButton`)
                        VStack(alignment: .leading) {
                            HStack {
                                Image(systemName: "basket.fill") // Basket icon
                                   // .foregroundColor(.orange)
                                Text("Basket")
                                    .font(.custom(fontName, size: 24))
                                    .foregroundColor(.black) // High contrast text color
                                Spacer()
                                Button(action: { showWordBasketView = true }) {
                                    Text("See All")
                                        .font(.custom(fontName, size: 18))
                                        .foregroundColor(.blue)
                                }
                            }
                            .padding([.leading, .trailing])

                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 12) {
                                    ForEach(Array(Set(projectManager.savedWords.flatMap { $0.value })).sorted(), id: \.self) { word in
                                        WordButton(word: word, points: $projectManager.points)
                                    }
                                }
                                .padding([.leading, .trailing])
                            }
                        }
                        .padding(.top)
                    }
                    .padding()
                }
                .background(Color.pastel) // Full screen pastel cream background
                .edgesIgnoringSafeArea(.all)
            }
            .confirmationDialog("Upload Image", isPresented: $showActionSheet, titleVisibility: .visible) {
                Button("Use Camera") { isCameraPresented = true }
                Button("Select from Gallery") { isImagePickerPresented = true }
                Button("Cancel", role: .cancel) { }
            }
            .fullScreenCover(isPresented: $isCameraPresented) {
                CameraView(selectedImages: $selectedImages, navigateToPreview: $navigateToPreview)
            }
            .fullScreenCover(isPresented: $isImagePickerPresented) {
                ImagePicker(selectedImages: $selectedImages, showCamera: $isCameraPresented, navigateToPreview: $navigateToPreview)
            }
            .sheet(isPresented: $showNamePrompt) {
                NamePromptView(userName: $projectManager.userName, showNamePrompt: $showNamePrompt)
            }
            .onAppear {
                if projectManager.userName.isEmpty {
                    showNamePrompt = true
                }
            }
            .navigationDestination(isPresented: $navigateToPreview) {
                ImagePreviewView(selectedImages: $selectedImages, points: $projectManager.points)
                    .onDisappear {
                        refreshContent()
                    }
            }
            .navigationDestination(isPresented: $navigateToProject) {
                ProjectImagesView(projectName: selectedProject ?? "", images: imagesInSelectedProject, points: $projectManager.points)
                    .onAppear {
                        refreshContent()
                    }
            }
            .navigationDestination(isPresented: $showWordBasketView) {
                WordBasketView(points: $projectManager.points)
                    .onDisappear {
                        refreshContent()
                    }
            }
        }
    }

}

struct NamePromptView: View {
    @Binding var userName: String
    @Binding var showNamePrompt: Bool
    
    var body: some View {
        VStack {
            Text("Enter your name")
                .font(.custom("OpenDyslexic", size: 24))
                .padding()
            
            TextField("Name", text: $userName)
                .font(.custom("OpenDyslexic", size: 18))
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
                .autocapitalization(.words)
                .disableAutocorrection(true)
            
            Button(action: {
                ProjectManager.shared.userName = userName
                showNamePrompt = false
            }) {
                Text("Save")
                    .font(.custom("OpenDyslexic", size: 18))
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.buttonColor)
                    .foregroundColor(.black)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 0.6)
                    )
                    .cornerRadius(10)
            }
            .padding(.horizontal)
        }
        .padding()
    }
}
struct WordButton: View {
    let word: String
    @Binding var points: Int
    @State private var showPronunciationPractice: Bool = false
    
    var body: some View {
        Button(action: {
            showPronunciationPractice = true
        }) {
            Text(word.capitalized)
                .font(.custom("OpenDyslexic", size: 18))
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
                .frame(maxWidth: .infinity)
        }
        .sheet(isPresented: $showPronunciationPractice) {
            PronunciationPracticeView(targetWord: .constant(word), points: $points)
        }
    }
}

extension ContentView {
    private func openProject(named project: String) {
        selectedProject = project
        imagesInSelectedProject = projectManager.getImages(for: project)
        navigateToProject = true
    }

    func refreshContent() {
        selectedImages = []
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

