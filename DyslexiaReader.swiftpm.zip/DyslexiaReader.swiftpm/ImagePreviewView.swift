import SwiftUI

extension Color {
    static let pastelCream = Color(red: 255 / 255, green: 253 / 255, blue: 208 / 255)
}

struct ImagePreviewView: View {
    @Binding var selectedImages: [UIImage]
    @Binding var points: Int
    @State private var isImagePickerPresented = false
    @State private var isCameraPresented = false
    @State private var showActionSheet = false
    @State private var navigateToTextProcessing = false
    @State private var showProjectSelection = false
    @State private var selectedProject: String?

    var body: some View {
        NavigationStack {
            VStack {
                ScrollView {
                    LazyVStack {
                        ForEach(Array(selectedImages.enumerated()), id: \.offset) { index, image in
                            ZStack(alignment: .topTrailing) {
                                Image(uiImage: image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(maxHeight: 200)
                                    .cornerRadius(10)
                                    .padding()
                                    .accessibilityLabel("Selected image \(index + 1)")
                                Button(action: {
                                    selectedImages.remove(at: index)
                                }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundColor(.red)
                                        .padding(8)
                                }
                                .accessibilityLabel("Remove image \(index + 1)")
                            }
                        }
                    }
                }
                .background(Color.pastel) // Full screen pastel cream background

                HStack(spacing: 10) {
                    Button(action: { showProjectSelection = true }) {
                        HStack {
                            Image(systemName: "folder")
                            Text("Store")
                        }
                        .font(.custom("OpenDyslexic", size: 18))
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.buttonColor)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 0.6)
                        )
                    }

                    Button(action: { navigateToTextProcessing = true }) {
                        HStack {
                            Image(systemName: "wand.and.stars")
                            Text("Process")
                        }
                        .font(.custom("OpenDyslexic", size: 18))
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.buttonColor)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 0.6)
                        )
                    }
                }
                .padding()
            }
            .navigationTitle(Text("Preview Images"))
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showActionSheet = true }) {
                        Image(systemName: "plus")
                            .resizable()
                            .frame(width: 22, height: 22)
                            .padding(8)
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(20)
                    }
                }
            }
            .actionSheet(isPresented: $showActionSheet) {
                ActionSheet(title: Text("Add More Images"), buttons: [
                    .default(Text("Use Camera")) { isCameraPresented = true },
                    .default(Text("Select from Gallery")) { isImagePickerPresented = true },
                    .cancel()
                ])
            }
            .fullScreenCover(isPresented: $isCameraPresented) {
                CameraView(selectedImages: $selectedImages, navigateToPreview: .constant(false))
            }
            .sheet(isPresented: $isImagePickerPresented) {
                ImagePicker(selectedImages: $selectedImages, showCamera: .constant(false), navigateToPreview: .constant(false))
            }
            .sheet(isPresented: $showProjectSelection) {
                ProjectSelectionView(selectedImages: $selectedImages, selectedProject: $selectedProject, navigateToTextProcessing: $navigateToTextProcessing, showProjectSelection: $showProjectSelection)
            }
            .navigationDestination(isPresented: $navigateToTextProcessing) {
                TextProcessingView(images: selectedImages, points: $points)
            }
        }
        
    }
}

struct ImagePreviewView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ImagePreviewView(selectedImages: .constant([]), points: .constant(0))
        }
    }
}

