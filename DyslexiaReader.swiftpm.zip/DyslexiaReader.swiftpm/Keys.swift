import Foundation

extension UserDefaults {
    private enum Keys {
        static let userName = "userName"
        static let points = "points"
    }

    /// The user's name stored in UserDefaults.
    /// Returns an empty string if no name is set.
    var userName: String {
        get {
            string(forKey: Keys.userName) ?? ""
        }
        set {
            setValue(newValue, forKey: Keys.userName)
        }
    }

    /// The user's points stored in UserDefaults.
    /// Returns 0 if no points are recorded.
    var points: Int {
        get {
            integer(forKey: Keys.points)
        }
        set {
            setValue(newValue, forKey: Keys.points)
        }
    }
}
