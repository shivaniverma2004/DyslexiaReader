import SwiftUI
import AVFoundation

struct LearningCard: View {
    let word: String
    @Binding var points: Int
    @State private var isSpeaking: Bool = false
    @State private var speechRate: Float = 0.5
    @State private var isRecording: Bool = false
    @State private var accuracyMessage: String = ""
    @StateObject private var speechRecognizer = SpeechRecognizer()

    var body: some View {
        VStack {
            Text(word.capitalized)
                .font(.custom("OpenDyslexic", size: 24))
                .padding()

            HStack(spacing: 15) {
                Button(action: toggleSpeech) {
                    Text(isSpeaking ? "Stop" : "Hear")
                        .font(.custom("OpenDyslexic", size: 18))
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(isSpeaking ? Color.gray.opacity(0.6) : Color.buttonColor)
                        .foregroundColor(.black)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 0.6)
                        )
                }
                .accessibilityLabel(isSpeaking ? "Stop speaking" : "Hear the word")

                Button(action: toggleRecording) {
                    Text(isRecording ? "Stop" : "Pronounce")
                        .font(.custom("OpenDyslexic", size: 18))
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(isRecording ? Color.gray.opacity(0.6) : Color.pastel)
                        .foregroundColor(.black)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 0.6)
                        )
                        .cornerRadius(10)
                }
                .accessibilityLabel(isRecording ? "Stop recording" : "Practice pronunciation")
            }
            .padding(.bottom)

            if !accuracyMessage.isEmpty {
                Text(accuracyMessage)
                    .font(.custom("OpenDyslexic", size: 18))
                    .padding(8)
                    .background(Color.yellow.opacity(0.8))
                    .cornerRadius(10)
                    .multilineTextAlignment(.center)
                    .padding(.bottom)
            } else {
                Spacer().frame(height: 18) // Maintain consistent spacing
            }

            Slider(value: $speechRate, in: 0.3...0.7, step: 0.1) {
                Text("Speech Rate")
                    .font(.custom("OpenDyslexic", size: 18))
            }
            .padding([.leading, .trailing])
        }
        .frame(width: 220, height: 320)
        .background(Color.pastel)
        .cornerRadius(10)
        .shadow(radius: 5)
        .accessibilityElement(children: .contain)
    }

    // MARK: - Speech Handling Methods

    private func toggleSpeech() {
        if isSpeaking {
            SpeechHelper.shared.stop()
            isSpeaking = false
        } else {
            isSpeaking = true
            SpeechHelper.shared.speak(word, pace: speechRate) {
                isSpeaking = false
            }
        }
    }

    private func toggleRecording() {
        if isRecording {
            speechRecognizer.stopRecording()
            evaluatePronunciation()
            isRecording = false
        } else {
            accuracyMessage = ""
            speechRecognizer.reset() // Ensure this method exists in SpeechRecognizer
            speechRecognizer.startRecording()
            isRecording = true
        }
    }

    // MARK: - Pronunciation Evaluation

    private func evaluatePronunciation() {
        let recognizedWord = speechRecognizer.recognizedText.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        let targetWord = word.lowercased()

        let accuracy = calculateSimilarity(between: targetWord, and: recognizedWord)
        let percentage = Int(accuracy * 100)
        accuracyMessage = "Accuracy: \(percentage)%"

        switch accuracy {
        case 0.8...1.0:
            points += 10
            ProjectManager.shared.addWord(word, to: "Learned")
            accuracyMessage += "\nExcellent! You've mastered this word."
        case 0.5..<0.8:
            points += 5
            ProjectManager.shared.addWord(word, to: "Practice")
            accuracyMessage += "\nGood job! Keep practicing."
        default:
            points += 1
            ProjectManager.shared.addWord(word, to: "Practice")
            accuracyMessage += "\nKeep trying! You'll get it."
        }
    }

    // MARK: - Similarity Calculation using Levenshtein Distance

    private func calculateSimilarity(between string1: String, and string2: String) -> Double {
        let distance = levenshteinDistance(string1, string2)
        let maxLength = max(string1.count, string2.count)
        return maxLength == 0 ? 1.0 : 1.0 - (Double(distance) / Double(maxLength))
    }

    private func levenshteinDistance(_ lhs: String, _ rhs: String) -> Int {
        let lhsChars = Array(lhs)
        let rhsChars = Array(rhs)

        var grid = [[Int]](repeating: [Int](repeating: 0, count: rhsChars.count + 1), count: lhsChars.count + 1)

        for i in 0...lhsChars.count {
            grid[i][0] = i
        }
        for j in 0...rhsChars.count {
            grid[0][j] = j
        }

        for i in 1...lhsChars.count {
            for j in 1...rhsChars.count {
                if lhsChars[i - 1] == rhsChars[j - 1] {
                    grid[i][j] = grid[i - 1][j - 1]
                } else {
                    grid[i][j] = 1 + min(
                        grid[i - 1][j],     // Deletion
                        grid[i][j - 1],     // Insertion
                        grid[i - 1][j - 1]  // Substitution
                    )
                }
            }
        }

        return grid[lhsChars.count][rhsChars.count]
    }
}

// MARK: - Preview

struct LearningCard_Previews: PreviewProvider {
    static var previews: some View {
        LearningCard(word: "Example", points: .constant(0))
            .previewLayout(.sizeThatFits)
    }
}
