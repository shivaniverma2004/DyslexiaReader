import SwiftUI

struct LearningView: View {
    @Binding var points: Int
    @State private var selectedWord: String = ""
    @State private var showPronunciationPopup: Bool = false

    var body: some View {
        VStack(alignment: .leading) {
            Text("Learning Words")
                .font(.custom("OpenDyslexic", size: 24))
                .padding(.top)
                .padding(.leading)

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if let learnedWordsSet = ProjectManager.shared.savedWords["Learned"], !learnedWordsSet.isEmpty {
                        let learnedWords = Array(learnedWordsSet)
                        wordSection(title: "Learned Words", words: learnedWords)
                    }

                    if let practiceWordsSet = ProjectManager.shared.savedWords["Practice"], !practiceWordsSet.isEmpty {
                        let practiceWords = Array(practiceWordsSet)
                        wordSection(title: "Words to Practice", words: practiceWords)
                    }

                    if (ProjectManager.shared.savedWords["Learned"]?.isEmpty ?? true) &&
                        (ProjectManager.shared.savedWords["Practice"]?.isEmpty ?? true) {
                        Text("No words to display. Start by processing some images!")
                            .font(.custom("OpenDyslexic", size: 18))
                            .padding(.horizontal)
                            .padding(.top, 50)
                            .multilineTextAlignment(.center)
                    }
                }
                .padding(.top)
            }
            .sheet(isPresented: $showPronunciationPopup) {
                PronunciationPracticeView(targetWord: $selectedWord, points: $points)
            }
        }
        .navigationTitle("Learning Words")
    }

    @ViewBuilder
    private func wordSection(title: String, words: [String]) -> some View {
        Text(title)
            .font(.custom("OpenDyslexic", size: 20))
            .padding(.horizontal)

        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(spacing: 15) {
                ForEach(words.sorted(), id: \.self) { word in
                    Button(action: {
                        selectedWord = word
                        showPronunciationPopup = true
                    }) {
                        LearningCard(word: word, points: $points)
                    }
                }
                .buttonStyle(PlainButtonStyle())
            }
            .padding(.horizontal)
        }
    }
}

struct LearningView_Previews: PreviewProvider {
    static var previews: some View {
        LearningView(points: .constant(0))
    }
}
