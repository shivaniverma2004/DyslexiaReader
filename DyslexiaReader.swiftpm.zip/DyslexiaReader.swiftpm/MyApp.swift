import SwiftUI

@main
struct MyApp: App {
    init() {
        addFonts()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

func addFonts() {
    if let fontURL = Bundle.main.url(forResource: "OpenDyslexic-Regular", withExtension: "otf"),
       let fontData = try? Data(contentsOf: fontURL) as CFData,
       let provider = CGDataProvider(data: fontData),
       let font = CGFont(provider) {
        CTFontManagerRegisterGraphicsFont(font, nil)
    }
}

extension Color {
    static let pastel = Color(red: 251 / 255, green: 226 / 255, blue: 206 / 255 , opacity: 0.5)
    static let buttonColor = Color(red: 228 / 255, green: 210 / 255, blue: 191 / 255, opacity: 0.4)
    static let pastelYellow = Color(red: 255 / 255, green: 253 / 255, blue: 208 / 255)
    static let pastelPeach = Color(red: 255 / 255, green: 229 / 255, blue: 180 / 255)
    static let pastelLavender = Color(red: 230 / 255, green: 230 / 255, blue: 250 / 255)
    static let pastelMint = Color(red: 204 / 255, green: 255 / 255, blue: 204 / 255)
}

