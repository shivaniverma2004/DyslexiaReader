import Foundation
import UIKit

struct Project: Identifiable {
    let id: UUID
    let name: String
    var images: [UIImage]
}
