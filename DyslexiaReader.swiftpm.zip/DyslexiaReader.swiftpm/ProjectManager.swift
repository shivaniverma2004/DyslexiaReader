import Foundation
import UIKit

class ProjectManager: ObservableObject {
    @MainActor static let shared = ProjectManager()
    
    private let projectsKey = "savedProjects"
    private let wordsKey = "savedWords"
    private let userNameKey = "userName"
    private let pointsKey = "points"
    private let wordAccuracyKey = "wordAccuracy"
    
    /// Dictionary to store projects with their associated images.
    @Published var projects: [String: [UIImage]] = [:] {
        didSet {
            saveProjects()
        }
    }
    
    /// Dictionary to store words categorized under different sections (e.g., "Learned", "Practice", "Basket").
    @Published var savedWords: [String: Set<String>] = [:] {
        didSet {
            saveWords()
        }
    }

    /// Dictionary to store word accuracy percentages.
    @Published var wordAccuracy: [String: Int] = [:] {
        didSet {
            saveWordAccuracy()
        }
    }
    
    /// The user's name, stored in UserDefaults.
    @Published var userName: String {
        didSet {
            UserDefaults.standard.setValue(userName, forKey: userNameKey)
        }
    }
    
    /// The user's points, stored in UserDefaults.
    @Published var points: Int {
        didSet {
            UserDefaults.standard.setValue(points, forKey: pointsKey)
        }
    }

    /// An array of project names for easy access.
    var projectNames: [String] {
        return Array(projects.keys)
    }
    
    private init() {
        self.points = UserDefaults.standard.integer(forKey: pointsKey)
        self.userName = UserDefaults.standard.string(forKey: userNameKey) ?? ""
        loadProjects()
        loadWords()
        loadWordAccuracy()
    }
    
    // MARK: - Project Management
    
    /// Creates a new project with a given name if it doesn't already exist.
    func createProject(name: String) {
        if projects[name] == nil {
            projects[name] = []
            saveProjects()
        }
    }
    
    /// Adds images to a specified project.
    func addImages(_ images: [UIImage], to project: String) {
        if projects[project] != nil {
            projects[project]?.append(contentsOf: images)
        } else {
            projects[project] = images
        }
        saveProjects()
    }
    
    /// Retrieves images associated with a given project.
    func getImages(for project: String) -> [UIImage] {
        return projects[project] ?? []
    }
    
    // MARK: - Word Management
    
    /// Adds a word to a specific category, ensuring no duplicates are added.
    func addWord(_ word: String, to category: String) {
        let lowercasedWord = word.lowercased()
        if savedWords[category] == nil {
            savedWords[category] = Set<String>()
        }
        
        // Check if the word already exists to avoid duplicates
        if !(savedWords[category]?.contains(lowercasedWord) ?? false) {
            savedWords[category]?.insert(lowercasedWord)
            saveWords()
        }
    }

    /// Sets the accuracy percentage for a specific word.
    func setWordAccuracy(word: String, accuracy: Int) {
        wordAccuracy[word.lowercased()] = accuracy
        saveWordAccuracy()
    }
    
    // MARK: - Points Management
    
    /// Increments the user's points by a specified value.
    func incrementPoints(by value: Int) {
        points += value
    }
    
    // MARK: - Persistence Methods
    
    /// Saves projects to UserDefaults.
    func saveProjects() {
        let projectData = projects.mapValues { images in
            images.compactMap { image in
                // Compress images before saving to reduce data size
                image.jpegData(compressionQuality: 0.5)
            }
        }
        if let data = try? JSONEncoder().encode(projectData) {
            UserDefaults.standard.set(data, forKey: projectsKey)
        }
    }
    
    /// Loads projects from UserDefaults.
    func loadProjects() {
        if let data = UserDefaults.standard.data(forKey: projectsKey),
           let projectData = try? JSONDecoder().decode([String: [Data]].self, from: data) {
            projects = projectData.mapValues { dataArray in
                dataArray.compactMap { UIImage(data: $0) }
            }
        }
    }
    
    /// Saves words to UserDefaults.
    func saveWords() {
        // Convert Set to Array for encoding
        let wordsData = savedWords.mapValues { Array($0) }
        if let data = try? JSONEncoder().encode(wordsData) {
            UserDefaults.standard.set(data, forKey: wordsKey)
        }
    }
    
    /// Loads words from UserDefaults.
    func loadWords() {
        if let data = UserDefaults.standard.data(forKey: wordsKey),
           let wordsData = try? JSONDecoder().decode([String: [String]].self, from: data) {
            // Convert Array back to Set
            savedWords = wordsData.mapValues { Set($0) }
        }
    }

    /// Saves word accuracy to UserDefaults.
    func saveWordAccuracy() {
        if let data = try? JSONEncoder().encode(wordAccuracy) {
            UserDefaults.standard.set(data, forKey: wordAccuracyKey)
        }
    }

    /// Loads word accuracy from UserDefaults.
    func loadWordAccuracy() {
        if let data = UserDefaults.standard.data(forKey: wordAccuracyKey),
           let wordAccuracyData = try? JSONDecoder().decode([String: Int].self, from: data) {
            wordAccuracy = wordAccuracyData
        }
    }
}
