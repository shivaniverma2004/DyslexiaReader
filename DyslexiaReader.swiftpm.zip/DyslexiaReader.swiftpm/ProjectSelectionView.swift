import SwiftUI

struct ProjectSelectionView: View {
    @Binding var selectedImages: [UIImage]
    @Binding var selectedProject: String?
    @Binding var navigateToTextProcessing: Bool
    @Binding var showProjectSelection: Bool
    @State private var newProjectName: String = ""
    @State private var createNewProject: Bool = false
    @State private var showAlert: Bool = false
    @State private var alertMessage: String = ""

    var body: some View {
        NavigationView {
            VStack {
                Text("Select or Create Project")
                    .font(.custom("OpenDyslexic", size: 24))
                    .padding(.top)
                    .padding(.bottom, 10)

                List {
                    Section(header: Text("Existing Projects")
                                .font(.custom("OpenDyslexic", size: 20))) {
                        if ProjectManager.shared.projectNames.isEmpty {
                            Text("No projects available.")
                                .font(.custom("OpenDyslexic", size: 18))
                                .foregroundColor(.gray)
                        } else {
                            ForEach(ProjectManager.shared.projectNames, id: \.self) { project in
                                Button(action: {
                                    selectProject(named: project)
                                }) {
                                    Text(project)
                                        .font(.custom("OpenDyslexic", size: 18))
                                        .padding(.vertical, 5)
                                }
                                .accessibilityLabel("Select project \(project)")
                            }
                        }
                    }

                    if createNewProject {
                        Section(header: Text("Create New Project")
                                    .font(.custom("OpenDyslexic", size: 20))) {
                            TextField("Enter new project name", text: $newProjectName)
                                .font(.custom("OpenDyslexic", size: 18))
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .padding(.vertical, 5)
                                .padding(.horizontal)

                            Button(action: {
                                createAndAddToProject()
                            }) {
                                Text("Create and Add")
                                    .font(.custom("OpenDyslexic", size: 18))
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.buttonColor)
                                    .foregroundColor(.black)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(Color.black, lineWidth: 0.6)
                                    )
                                    .cornerRadius(10)
                            }
                            .disabled(newProjectName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        }
                    }

                    Button(action: {
                        withAnimation {
                            createNewProject.toggle()
                        }
                    }) {
                        Text(createNewProject ? "Cancel" : "Create New Project")
                            .font(.custom("OpenDyslexic", size: 18))
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(createNewProject ? Color.gray.opacity(0.6) : Color.buttonColor)
                            .foregroundColor(createNewProject ? Color.white : Color.black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 0.6)
                            )
                    }
                    .padding(.top)
                }
                .listStyle(InsetGroupedListStyle())
            }
            .padding(.horizontal)
            .navigationBarTitle("Projects", displayMode: .inline)
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Invalid Project Name"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }.background(Color.pastel)
    }

    // MARK: - Helper Methods

    private func selectProject(named project: String) {
        selectedProject = project
        ProjectManager.shared.addImages(selectedImages, to: project)
        navigateToTextProcessing = true
        showProjectSelection = false
    }

    private func createAndAddToProject() {
        let trimmedName = newProjectName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else {
            alertMessage = "Project name cannot be empty."
            showAlert = true
            return
        }

        if ProjectManager.shared.projectNames.contains(trimmedName) {
            alertMessage = "A project with this name already exists."
            showAlert = true
            return
        }

        ProjectManager.shared.createProject(name: trimmedName)
        ProjectManager.shared.addImages(selectedImages, to: trimmedName)
        selectedProject = trimmedName
        navigateToTextProcessing = true
        showProjectSelection = false
        createNewProject = false
        newProjectName = ""
    }
}

struct ProjectSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        ProjectSelectionView(
            selectedImages: .constant([]),
            selectedProject: .constant(nil),
            navigateToTextProcessing: .constant(false),
            showProjectSelection: .constant(true)
        )
    }
}
