import SwiftUI

struct ProjectsView: View {
    @Binding var points: Int
    @State private var selectedProject: String?
    @State private var navigateToImages: Bool = false
    @State private var imagesInSelectedProject: [UIImage] = []

    var body: some View {
        VStack {
            if ProjectManager.shared.projectNames.isEmpty {
                Text("No projects available. Please add images to create a project.")
                    .font(.custom("OpenDyslexic", size: 18))
                    .padding()
                    .multilineTextAlignment(.center)
            } else {
                ScrollView {
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 20), GridItem(.flexible(), spacing: 20)], spacing: 20) {
                        ForEach(ProjectManager.shared.projectNames, id: \.self) { project in
                            if let firstImage = ProjectManager.shared.getImages(for: project).first {
                                Button(action: {
                                    selectProject(named: project)
                                }) {
                                    ProjectPreviewCard(projectName: project, image: firstImage)
                                        .accessibilityLabel("Project \(project)")
                                }
                            }
                        }
                    }
                    .padding([.horizontal, .top], 20)
                }
            }
        }
        .navigationTitle("Projects")
        .background(Color.pastel)
        .navigationBarTitleDisplayMode(.inline)
        .navigationDestination(isPresented: $navigateToImages) {
            ProjectImagesView(projectName: selectedProject ?? "", images: imagesInSelectedProject, points: $points)
        }
    }

    // MARK: - Helper Methods

    private func selectProject(named project: String) {
        selectedProject = project
        imagesInSelectedProject = ProjectManager.shared.getImages(for: project)
        navigateToImages = true
    }
}

struct ProjectImagesView: View {
    let projectName: String
    let images: [UIImage]
    @Binding var points: Int

    var body: some View {
        ScrollView {
            if images.isEmpty {
                Text("No images in this project.")
                    .font(.custom("OpenDyslexic", size: 18))
                    .padding()
            } else {
                LazyVStack {
                    ForEach(Array(images.enumerated()), id: \.offset) { index, image in
                        NavigationLink {
                            TextProcessingView(images: [image], points: $points)
                        } label: {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                                .frame(maxHeight: 200)
                                .cornerRadius(10)
                                .padding()
                                .shadow(radius: 5)
                        }
                        .accessibilityLabel("Image \(index + 1) in project \(projectName)")
                    }
                }
                .padding(.horizontal)
            }
        }
        .navigationTitle(projectName)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ProjectPreviewCard: View {
    let projectName: String
    let image: UIImage

    var body: some View {
        VStack(spacing: 0) {
            Image(uiImage: image)
                .resizable()
                .scaledToFill()
                .frame(height: 140)
                .cornerRadius(10, corners: [.topLeft, .topRight])
                .clipped()
            
            Text(projectName)
                .font(.custom("OpenDyslexic", size: 20))
                .foregroundColor(.black)
                .background(Color.clear)
                .frame(height: 60)
                .cornerRadius(10, corners: [.bottomLeft, .bottomRight])
        }
        .frame(width: 170 , height: 200)
        .background(Color.gray.opacity(0.2))
        .cornerRadius(10)
        .shadow(radius: 2)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.black, lineWidth: 0.25)
        )
        .padding(.horizontal)
    }
}

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

struct ProjectsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ProjectsView(points: .constant(0))
        }
    }
}
