import SwiftUI
import AVFoundation

struct PronunciationPracticeView: View {
    @Binding var targetWord: String
    @Binding var points: Int

    @State private var isSpeaking: Bool = false
    @State private var speechRate: Float = 0.5

    @State private var isRecording: Bool = false
    @State private var accuracyMessage: String = ""

    @StateObject private var speechHelper = SpeechHelper.shared
    @StateObject private var evaluator = PronunciationEvaluator()

    var body: some View {
        VStack(spacing: 20) {
            Text(targetWord.capitalized)
                .font(.custom("OpenDyslexic", size: 24))
                .padding()

            Button(action: toggleSpeech) {
                HStack {
                    Image(systemName: isSpeaking ? "stop.fill" : "speaker.wave.2.fill")
                        .foregroundColor(.black)
                    Text(isSpeaking ? "Stop" : "Hear")
                        .font(.custom("OpenDyslexic", size: 18))
                        .foregroundColor(.black)
                }
                    .font(.custom("OpenDyslexic", size: 18))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(isSpeaking ? Color.gray.opacity(0.6) : Color.buttonColor)
                    .foregroundColor(.black)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 0.6)
                    )
                    .cornerRadius(10)
            }
            .accessibilityLabel(isSpeaking ? "Stop speaking \(targetWord)" : "Hear \(targetWord)")

            Button(action: toggleRecording) {
                HStack {
                    Image(systemName: isRecording ? "stop.fill" : "mic.fill")
                        .foregroundColor(.black)
                    Text(isRecording ? "Stop" : "Pronounce")
                        .font(.custom("OpenDyslexic", size: 18))
                        .foregroundColor(.black)
                }
                .padding()
                .frame(maxWidth: .infinity)
                    .background(isRecording ? Color.gray.opacity(0.6) : Color.pastelPeach)
                    .foregroundColor(.black)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 0.6)
                    )
                    .cornerRadius(10)
            }
            .accessibilityLabel(isRecording ? "Stop recording" : "Practice pronouncing \(targetWord)")

            Slider(value: $speechRate, in: 0.3...0.7, step: 0.1) {
                Text("Speech Rate")
                    .font(.custom("OpenDyslexic", size: 16))
            }
            .padding(.horizontal)

            if !accuracyMessage.isEmpty {
                Text(accuracyMessage)
                    .font(.custom("OpenDyslexic", size: 18))
                    .padding()
                    .background(Color.yellow.opacity(0.8))
                    .cornerRadius(10)
                    .multilineTextAlignment(.center)
            }

            Spacer()
        }
        .padding()
        .background(Color.pastel)
        .navigationBarTitle("Practice Pronunciation", displayMode: .inline)
        .onDisappear {
            stopAllAudio()
        }
    }

    private func toggleSpeech() {
        if isSpeaking {
            speechHelper.stop()
            isSpeaking = false
        } else {
            stopRecordingIfNeeded()
            isSpeaking = true
            speechHelper.speak(targetWord, pace: speechRate) {
                isSpeaking = false
            }
        }
    }

    private func toggleRecording() {
        if isRecording {
            evaluator.stopRecording()
            evaluatePronunciation()
            isRecording = false
        } else {
            stopSpeechIfNeeded()
            accuracyMessage = ""
            evaluator.reset()
            evaluator.startRecording()
            if let error = evaluator.errorMessage {
                accuracyMessage = error
                isRecording = false
            } else {
                isRecording = true
            }
        }
    }

    private func evaluatePronunciation() {
        let accuracy = evaluator.evaluatePronunciation(for: targetWord)
        let percentage = Int(accuracy * 100)
        accuracyMessage = "Accuracy: \(percentage)%"

        ProjectManager.shared.setWordAccuracy(word: targetWord, accuracy: percentage)

        switch accuracy {
        case 0.8...1.0:
            points += 10
            ProjectManager.shared.addWord(targetWord, to: "Learned")
            accuracyMessage += "\nExcellent! You've mastered this word."
        case 0.5..<0.8:
            points += 5
            ProjectManager.shared.addWord(targetWord, to: "Practice")
            accuracyMessage += "\nGood job! Keep practicing."
        case 0.0:
            points += 1
            ProjectManager.shared.addWord(targetWord, to: "Practice")
            accuracyMessage += "\nKeep trying! You'll get it."
        default:
            points += 1
            ProjectManager.shared.addWord(targetWord, to: "Practice")
            accuracyMessage += "\nKeep trying! You'll get it."
        }

        ProjectManager.shared.points = points
    }

    private func stopSpeechIfNeeded() {
        if isSpeaking {
            speechHelper.stop()
            isSpeaking = false
        }
    }

    private func stopRecordingIfNeeded() {
        if isRecording {
            evaluator.stopRecording()
            isRecording = false
        }
    }

    private func stopAllAudio() {
        stopSpeechIfNeeded()
        stopRecordingIfNeeded()
    }
}
