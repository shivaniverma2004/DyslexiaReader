import Foundation
import AVFoundation
import Speech
import SwiftUI

@MainActor
class SpeechRecognizer: NSObject, ObservableObject, @unchecked Sendable {
    @Published var recognizedText: String = ""
    @Published var isRecording: Bool = false
    @Published var errorMessage: String?

    private var audioEngine: AVAudioEngine?
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let speechRecognizer: SFSpeechRecognizer?

    override init() {
        // Initialize the speech recognizer with the device's locale
        if let locale = Locale.current.language.languageCode?.identifier {
            speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: locale))
        } else {
            speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        }
        super.init()
        requestAuthorization()
    }

    // MARK: - Authorization

    private func requestAuthorization() {
        Task { @MainActor [weak self] in
            await SFSpeechRecognizer.requestAuthorization { authStatus in
                Task { @MainActor [weak self] in
                    switch authStatus {
                    case .authorized:
                        // Authorized to perform speech recognition
                        break
                    case .denied:
                        self?.errorMessage = "Speech recognition authorization was denied."
                    case .restricted:
                        self?.errorMessage = "Speech recognition is restricted on this device."
                    case .notDetermined:
                        self?.errorMessage = "Speech recognition authorization not determined."
                    @unknown default:
                        self?.errorMessage = "An unknown error occurred during authorization."
                    }
                }
            }
        }
    }

    // MARK: - Recording Control

    /// Starts recording and transcribing speech.
    func startRecording() {
        errorMessage = nil
        recognizedText = ""

        // Ensure the speech recognizer is available
        guard let speechRecognizer = speechRecognizer, speechRecognizer.isAvailable else {
            errorMessage = "Speech recognition is not available at the moment."
            return
        }

        // Setup audio engine and recognition request
        audioEngine = AVAudioEngine()
        request = SFSpeechAudioBufferRecognitionRequest()

        guard let recognitionRequest = request else {
            errorMessage = "Failed to create recognition request."
            return
        }

        // Configure the recognition request
        recognitionRequest.shouldReportPartialResults = true

        let audioSession = AVAudioSession.sharedInstance()
        do {
            // Configure audio session for recording
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            errorMessage = "Audio session error: \(error.localizedDescription)"
            return
        }

        // Prepare the audio input
        guard let inputNode = audioEngine?.inputNode else {
            errorMessage = "Audio engine has no input node."
            return
        }

        // Prepare the recognition task
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            Task { @MainActor [weak self] in
                if let error = error {
                    self?.errorMessage = "Recognition error: \(error.localizedDescription)"
                    self?.stopRecording()
                    return
                }

                if let result = result {
                    // Update the recognized text
                    self?.recognizedText = result.bestTranscription.formattedString
                }
            }
        }

        // Install tap on the audio engine's input node to capture audio samples
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.removeTap(onBus: 0) // Remove existing taps if any
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, _ in
            self?.request?.append(buffer)
        }

        // Start the audio engine
        do {
            try audioEngine?.start()
            isRecording = true
        } catch {
            errorMessage = "Audio engine couldn't start: \(error.localizedDescription)"
        }
    }

    /// Stops recording and transcribing.
    func stopRecording() {
        audioEngine?.stop()
        audioEngine?.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        recognitionTask?.cancel()

        isRecording = false
    }

    /// Resets the recognizer to prepare for a new session.
    func reset() {
        stopRecording()
        recognizedText = ""
        errorMessage = nil
    }
}
