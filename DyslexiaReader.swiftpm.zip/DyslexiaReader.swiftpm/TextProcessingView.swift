import SwiftUI
import AVFoundation
@preconcurrency import Vision


struct TextProcessingView: View {
    var images: [UIImage]
    @Binding var points: Int

    // State variables for text recognition and processing
    @State private var recognizedText: String = ""
    @State private var isProcessing: Bool = false
    @State private var errorMessage: String?

    // State variables for text appearance and speech
    @State private var fontSize: CGFloat = 18
    @State private var lineSpacing: CGFloat = 1.5
    @State private var speechRate: Float = 0.5
    @State private var isSpeaking: Bool = false

    // State variables for selected word and word options
    @State private var selectedWord: String = ""
    @State private var showWordOptions: Bool = false

    // State variable for sliding panel
    @State private var showSlidingPanel: Bool = true

    // Instantiate SpeechHelper as a StateObject
    @StateObject private var speechHelper = SpeechHelper.shared

    var body: some View {
        ZStack {
            VStack {
                if isProcessing {
                    ProgressView("Processing Images...")
                        .font(.custom("OpenDyslexic", size: 18))
                        .padding()
                } else if !recognizedText.isEmpty {
                    ScrollView {
                        TextViewWrapper(
                            text: $recognizedText,
                            fontSize: $fontSize,
                            lineSpacing: $lineSpacing,
                            selectedWord: $selectedWord,
                            showWordOptions: $showWordOptions
                        )
                        .frame(minHeight: 650)
                        .padding()
                        .background(Color.pastel) // Background color friendly to dyslexic users
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 0.7)
                        )
                        .padding()
                    }
                } else if let error = errorMessage {
                    Text(error)
                        .font(.custom("OpenDyslexic", size: 18))
                        .foregroundColor(.red)
                        .padding()
                } else {
                    Button(action: performTextRecognition) {
                        Text("Process Text")
                            .font(.custom("OpenDyslexic", size: 18))
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.buttonColor)
                            .foregroundColor(.black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 0.6)
                            )
                    }
                    .padding()
                }
            }

            if !recognizedText.isEmpty {
                VStack {
                    Spacer()
                    SlidingPanel(
                        fontSize: $fontSize,
                        lineSpacing: $lineSpacing,
                        speechRate: $speechRate,
                        isSpeaking: $isSpeaking,
                        recognizedText: $recognizedText,
                        toggleReadAloud: toggleReadAloud,
                        showSlidingPanel: $showSlidingPanel
                    )
                }
                .edgesIgnoringSafeArea(.all)
            }

            // Add a button to toggle the sliding panel
            if !recognizedText.isEmpty {
                VStack {
                    HStack {
                        Spacer()
                        Button(action: {
                            withAnimation {
                                showSlidingPanel.toggle()
                            }
                        }) {
                            Image(systemName: showSlidingPanel ? "chevron.down" : "chevron.up")
                                .resizable()
                                .frame(width: 20, height: 10)
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(10)
                                .padding()
                        }
                    }
                    Spacer()
                }
            }
        }
        .navigationTitle("Text Processing")
        .sheet(isPresented: $showWordOptions) {
            WordOptionsPopup(
                word: selectedWord,
                points: $points,
                showPopup: $showWordOptions
            )
        }
        .onDisappear {
            stopSpeechIfNeeded()
        }
    }

    // Actions
    private func performTextRecognition() {
        recognizedText = ""
        isProcessing = true
        errorMessage = nil
        showSlidingPanel = false

        let textRecognitionRequest = VNRecognizeTextRequest { request, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.errorMessage = "Text recognition error: \(error.localizedDescription)"
                    self.isProcessing = false
                }
                return
            }

            guard let observations = request.results as? [VNRecognizedTextObservation], !observations.isEmpty else {
                DispatchQueue.main.async {
                    self.errorMessage = "No text found in images."
                    self.isProcessing = false
                }
                return
            }

            var text = ""
            for observation in observations {
                if let topCandidate = observation.topCandidates(1).first {
                    text += topCandidate.string + "\n"
                }
            }

            DispatchQueue.main.async {
                self.recognizedText += text
                self.isProcessing = false
            }
        }

        textRecognitionRequest.recognitionLevel = .accurate
        textRecognitionRequest.usesLanguageCorrection = true

        DispatchQueue.global(qos: .userInitiated).async {
            for image in self.images {
                guard let cgImage = image.cgImage else { continue }
                let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                do {
                    try handler.perform([textRecognitionRequest])
                } catch {
                    DispatchQueue.main.async {
                        self.errorMessage = "Failed to perform text recognition: \(error.localizedDescription)"
                        self.isProcessing = false
                    }
                    return
                }
            }
        }
    }

    private func toggleReadAloud() {
        if isSpeaking {
            speechHelper.stop()
            isSpeaking = false
        } else {
            isSpeaking = true
            speechHelper.speak(recognizedText, pace: speechRate) {
                isSpeaking = false
            }
        }
    }

    private func stopSpeechIfNeeded() {
        if isSpeaking {
            speechHelper.stop()
            isSpeaking = false
        }
    }
}

// SlidingPanel View
struct SlidingPanel: View {
    @Binding var fontSize: CGFloat
    @Binding var lineSpacing: CGFloat
    @Binding var speechRate: Float
    @Binding var isSpeaking: Bool
    @Binding var recognizedText: String
    var toggleReadAloud: () -> Void
    @Binding var showSlidingPanel: Bool

    var body: some View {
        VStack(spacing: 15) {
            Capsule()
                .fill(Color.gray)
                .frame(width: 40, height: 6)
                .padding(.vertical, 10)
                .gesture(
                    DragGesture()
                        .onEnded { value in
                            if value.translation.height > 50 {
                                withAnimation {
                                    showSlidingPanel = false
                                }
                            }
                        }
                )

            // Content of the panel
            // Font Size Slider
            HStack {
                Text("Font Size: \(Int(fontSize))")
                    .font(.custom("OpenDyslexic", size: 16))
                Slider(value: $fontSize, in: 14...30, step: 1)
                    .accentColor(.blue)
            }
            .padding(.horizontal)

            // Line Spacing Slider
            HStack {
                Text("Line Spacing: \(String(format: "%.1f", lineSpacing))")
                    .font(.custom("OpenDyslexic", size: 16))
                Slider(value: $lineSpacing, in: 1...3, step: 0.1)
                    .accentColor(.blue)
            }
            .padding(.horizontal)

            // Read Aloud Button
            Button(action: toggleReadAloud) {
                HStack {
                    Image(systemName: isSpeaking ? "stop.fill" : "speaker.wave.2.fill")
                        .foregroundColor(.black)
                    Text(isSpeaking ? "Stop" : "Hear")
                        .font(.custom("OpenDyslexic", size: 18))
                        .foregroundColor(.black)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(isSpeaking ? Color.gray.opacity(0.6) : Color.buttonColor)
                .cornerRadius(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black, lineWidth: 0.6)
                )
            }
            .padding(.horizontal)
            .disabled(recognizedText.isEmpty)

            // Speech Rate Slider
            HStack {
                Text("Speech Rate")
                    .font(.custom("OpenDyslexic", size: 16))
                Slider(value: $speechRate, in: 0.3...0.7, step: 0.1)
                    .accentColor(.blue)
            }
            .padding(.horizontal)

            Spacer()
        }
        .frame(height: UIScreen.main.bounds.height * 0.4)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 10)
        .offset(y: showSlidingPanel ? 0 : UIScreen.main.bounds.height * 0.4)
        .animation(.easeInOut)
    }
}


struct TextProcessingView_Previews: PreviewProvider {
    static var previews: some View {
        TextProcessingView(images: [], points: .constant(0))
    }
}
