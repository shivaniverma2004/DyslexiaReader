import Foundation
@preconcurrency import Vision  // Suppress 'Sendable'-related warnings from Vision module
import UIKit
import SwiftUI

@MainActor
class TextRecognition: ObservableObject {
    @Published var recognizedText: String = ""
    @Published var isProcessing: Bool = false
    @Published var errorMessage: String?

    func recognizeText(from images: [UIImage]) {
        recognizedText = ""
        isProcessing = true
        errorMessage = nil

        // Perform the request asynchronously
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }

            for image in images {
                autoreleasepool {
                    guard let cgImage = image.cgImage else {
                        return  // Use return to skip this iteration
                    }

                    // Create the text recognition request inside the closure
                    let textRecognitionRequest = VNRecognizeTextRequest { request, error in
                        if let error = error {
                            Task { @MainActor in
                                self.errorMessage = "Text recognition error: \(error.localizedDescription)"
                                self.isProcessing = false
                            }
                            return
                        }

                        guard let observations = request.results as? [VNRecognizedTextObservation], !observations.isEmpty else {
                            Task { @MainActor in
                                self.errorMessage = "No text was found in the images."
                                self.isProcessing = false
                            }
                            return
                        }

                        var fullText = ""
                        for observation in observations {
                            if let topCandidate = observation.topCandidates(1).first {
                                fullText += topCandidate.string + "\n"
                            }
                        }

                        Task { @MainActor in
                            self.recognizedText += fullText
                        }
                    }

                    textRecognitionRequest.recognitionLevel = .accurate
                    textRecognitionRequest.usesLanguageCorrection = true

                    let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                    do {
                        try handler.perform([textRecognitionRequest])
                    } catch {
                        Task { @MainActor in
                            self.errorMessage = "Failed to perform text recognition: \(error.localizedDescription)"
                            self.isProcessing = false
                        }
                        return
                    }
                }
            }

            // After processing all images
            Task { @MainActor in
                self.isProcessing = false
            }
        }
    }
}
