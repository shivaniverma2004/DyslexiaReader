import SwiftUI
import UIKit

struct TextViewWrapper: UIViewRepresentable {
    @Binding var text: String
    @Binding var fontSize: CGFloat
    @Binding var lineSpacing: CGFloat
    @Binding var selectedWord: String
    @Binding var showWordOptions: Bool

    func makeUIView(context: Context) -> UITextView {
        let textView = UITextView()
        textView.isEditable = false
        textView.isSelectable = false
        textView.backgroundColor = .clear
        textView.textContainerInset = .zero
        textView.textContainer.lineFragmentPadding = 0
        textView.delegate = context.coordinator

        textView.isUserInteractionEnabled = true

        let tapGesture = UITapGestureRecognizer(target: context.coordinator, action: #selector(context.coordinator.handleTap(_:)))
        tapGesture.cancelsTouchesInView = false  // Allow other interactions
        textView.addGestureRecognizer(tapGesture)

        return textView
    }

    func updateUIView(_ uiView: UITextView, context: Context) {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = lineSpacing

        let attributes: [NSAttributedString.Key: Any] = [
            .font: UIFont(name: "OpenDyslexic", size: fontSize) ?? UIFont.systemFont(ofSize: fontSize),
            .paragraphStyle: paragraphStyle
        ]
        uiView.attributedText = NSAttributedString(string: text, attributes: attributes)

        // Ensure the gesture recognizer is attached
        if uiView.gestureRecognizers == nil || uiView.gestureRecognizers?.isEmpty == true {
            let tapGesture = UITapGestureRecognizer(target: context.coordinator, action: #selector(context.coordinator.handleTap(_:)))
            tapGesture.cancelsTouchesInView = false
            uiView.addGestureRecognizer(tapGesture)
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    class Coordinator: NSObject, UITextViewDelegate {
        var parent: TextViewWrapper

        init(parent: TextViewWrapper) {
            self.parent = parent
        }

        @objc func handleTap(_ gesture: UITapGestureRecognizer) {
            guard let textView = gesture.view as? UITextView else { return }
            let location = gesture.location(in: textView)

            if let position = textView.closestPosition(to: location),
               let wordRange = textView.tokenizer.rangeEnclosingPosition(position, with: .word, inDirection: UITextDirection(rawValue: UITextStorageDirection.forward.rawValue)),
               let selectedWord = textView.text(in: wordRange) {
                DispatchQueue.main.async {
                    // Add haptic feedback
                    let generator = UIImpactFeedbackGenerator(style: .medium)
                    generator.impactOccurred()

                    self.parent.selectedWord = selectedWord
                    self.parent.showWordOptions = true
                }
            }
        }
    }
}
