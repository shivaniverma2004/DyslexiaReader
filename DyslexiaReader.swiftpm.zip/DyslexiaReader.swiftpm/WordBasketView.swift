import SwiftUI

struct WordBasketView: View {
    @Binding var points: Int
    @State private var selectedWord: String = ""
    @State private var showPronunciationPractice: Bool = false

    var body: some View {
        VStack(alignment: .leading) {
            // Title
            Text("Word Basket")
                .font(.custom("OpenDyslexic", size: 28))
                .padding(.top)
                .padding(.horizontal)

            // Content
            ScrollView {
                VStack(alignment: .leading, spacing: 30) {
                    // Retrieve words and filter based on accuracy
                    let basketWords = Array(ProjectManager.shared.savedWords["Basket"] ?? []).sorted()
                    let wordAccuracy = ProjectManager.shared.wordAccuracy

                    // Separate words based on accuracy
                    let learnedWords = basketWords.filter { wordAccuracy[$0] == 100 }.sorted()
                    let practiceWords = basketWords.filter { (wordAccuracy[$0] ?? 0) < 100 }.sorted()

                    // Basket Words Section
                    if !basketWords.isEmpty {
                        wordSection(title: "Basket Words", words: basketWords)
                    }
                    Divider()
                    // Learned Words Section (100% accuracy)
                    if !learnedWords.isEmpty {
                        wordSection(title: "Learned Words", words: learnedWords)
                    }
                    Divider()

                    // Words to Practice Section (<100% accuracy)
                    if !practiceWords.isEmpty {
                        wordSection(title: "Words to Practice", words: practiceWords)
                    }

                    // Empty State
                    if basketWords.isEmpty {
                        emptyStateView()
                    }
                }
                .padding(.top)
                .background(Color.pastel)
            }
        }
        .sheet(isPresented: $showPronunciationPractice) {
            PronunciationPracticeView(targetWord: $selectedWord, points: $points)
        }
    }

    // MARK: - Word Section View
    @ViewBuilder
    private func wordSection(title: String, words: [String]) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            Text(title)
                .font(.custom("OpenDyslexic", size: 22))
                .padding(.horizontal)

            ForEach(words, id: \.self) { word in
                Button(action: {
                    selectedWord = word
                    showPronunciationPractice = true
                }) {
                    HStack {
                        Text(word.capitalized)
                            .font(.custom("OpenDyslexic", size: 20))
                            .foregroundColor(.primary)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color(UIColor.secondarySystemBackground))
                            .shadow(color: Color.black.opacity(0.1), radius: 2, x: 0, y: 2)
                    )
                    .padding(.horizontal)
                }
                .buttonStyle(PlainButtonStyle())
                .accessibilityLabel("Practice \(word)")
            }
        }
        .padding(.bottom, 20)
    }

    // MARK: - Empty State View
    @ViewBuilder
    private func emptyStateView() -> some View {
        VStack(spacing: 20) {
            Image(systemName: "tray")
                .resizable()
                .scaledToFit()
                .frame(width: 80)
                .foregroundColor(.gray)
                .opacity(0.5)
            Text("Your Word Basket is empty.")
                .font(.custom("OpenDyslexic", size: 20))
                .foregroundColor(.gray)
            Text("Start by adding words to your basket!")
                .font(.custom("OpenDyslexic", size: 18))
                .foregroundColor(.gray)
        }
        .multilineTextAlignment(.center)
        .padding(.horizontal)
        .padding(.top, 50)
    }
}

struct WordBasketView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            WordBasketView(points: .constant(100))
                .preferredColorScheme(.light)
        }
        NavigationView {
            WordBasketView(points: .constant(100))
                .preferredColorScheme(.dark)
        }
    }
}
