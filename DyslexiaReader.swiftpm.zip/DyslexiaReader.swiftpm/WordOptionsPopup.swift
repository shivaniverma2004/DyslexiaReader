import SwiftUI

struct WordOptionsPopup: View {
    let word: String
    @Binding var points: Int
    @Binding var showPopup: Bool
    @State private var showPronunciationPractice: Bool = false
    @State private var showAddToBasketAlert: Bool = false
    @ObservedObject private var speechHelper = SpeechHelper.shared

    private var isWordInBasket: Bool {
        return ProjectManager.shared.savedWords["Basket"]?.contains(word.lowercased()) ?? false
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text(word.capitalized)
                    .font(.custom("OpenDyslexic", size: 24))
                    .padding()

                // Hear Pronunciation Button
                Button(action: {
                    speechHelper.speak(word)
                }) {
                    HStack {
                        Image(systemName: "speaker.wave.2.fill")
                            .foregroundColor(.black)
                        Text("Hear")
                            .font(.custom("OpenDyslexic", size: 18))
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.buttonColor)
                    .foregroundColor(.black)
                    .cornerRadius(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 0.6)
                    )
                }

                // Practice Pronunciation Button
                Button(action: {
                    showPronunciationPractice = true
                }) {
                    HStack {
                        Image(systemName: "mic.fill")
                            .foregroundColor(.black)
                        Text("Practice")
                            .font(.custom("OpenDyslexic", size: 18))
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.pastelPeach)
                    .foregroundColor(.black)
                    .cornerRadius(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 0.6)
                    )
                }
                .sheet(isPresented: $showPronunciationPractice) {
                    PronunciationPracticeView(targetWord: .constant(word), points: $points)
                }

                // Add to Basket Button
                Button(action: {
                    if !isWordInBasket {
                        ProjectManager.shared.addWord(word, to: "Basket")
                    }
                    showAddToBasketAlert = true
                }) {
                    HStack {
                        Image(systemName: "basket.fill")
                            .foregroundColor(.black)
                        Text(isWordInBasket ? "Added" : "Add")
                            .font(.custom("OpenDyslexic", size: 18))
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.pastelMint)
                    .foregroundColor(.black)
                    .cornerRadius(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 0.6)
                    )
                }
                .alert(isPresented: $showAddToBasketAlert) {
                    Alert(
                        title: Text("Word Added"),
                        message: Text("\(word.capitalized) has been added to the Basket."),
                        dismissButton: .default(Text("OK")) {
                            showPopup = false
                        }
                    )
                }

                // Cancel Button
                Button(action: {
                    showPopup = false
                }) {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.black)
                        Text("Cancel")
                            .font(.custom("OpenDyslexic", size: 18))
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.6))
                    .foregroundColor(.black)
                    .cornerRadius(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 0.6)
                    )
                }
            }
            .padding()
            .background(Color.pastel) // Example background color
            .navigationTitle("Word Options")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// Preview

struct WordOptionsPopup_Previews: PreviewProvider {
    static var previews: some View {
        WordOptionsPopup(
            word: "Example",
            points: .constant(0),
            showPopup: .constant(true)
        )
    }
}
