import SwiftUI
import AVFoundation

struct WordPopupView: View {
    let word: String
    @Binding var points: Int
    @State private var isSpeaking: Bool = false
    @State private var speechRate: Float = 0.5
    @State private var isRecording: Bool = false
    @State private var accuracyMessage: String = ""

    @StateObject private var speechHelper = SpeechHelper.shared
    @StateObject private var evaluator = PronunciationEvaluator()

    var body: some View {
        VStack(spacing: 20) {
            Text(word.capitalized)
                .font(.custom("OpenDyslexic", size: 24))
                .padding()

            // 📢 Speech Button
            Button(action: toggleSpeech) {
                Text(isSpeaking ? "Stop" : "Hear")
                    .font(.custom("OpenDyslexic", size: 18))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(isSpeaking ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .accessibilityLabel(isSpeaking ? "Stop speaking \(word)" : "Hear \(word)")

            // 🎤 Pronunciation Button
            Button(action: toggleRecording) {
                Text(isRecording ? "Stop" : "Pronounce")
                    .font(.custom("OpenDyslexic", size: 18))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(isRecording ? Color.red : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .accessibilityLabel(isRecording ? "Stop recording" : "Practice pronouncing \(word)")

            // 🔊 Speech Rate Slider
            Slider(value: $speechRate, in: 0.3...0.7, step: 0.1) {
                Text("Speech Rate")
                    .font(.custom("OpenDyslexic", size: 16))
            }
            .padding(.horizontal)

            // 📊 Accuracy Message
            if !accuracyMessage.isEmpty {
                Text(accuracyMessage)
                    .font(.custom("OpenDyslexic", size: 18))
                    .padding()
                    .background(Color.yellow.opacity(0.8))
                    .cornerRadius(10)
                    .multilineTextAlignment(.center)
            }

            Spacer()
        }
        .padding()
        .onDisappear {
            stopAllAudio()
        }
    }

    // MARK: - Actions

    private func toggleSpeech() {
        if isSpeaking {
            speechHelper.stop()
            isSpeaking = false
        } else {
            stopRecordingIfNeeded()  // Ensure recording is stopped before playing speech
            speechHelper.speak(word, pace: speechRate) {
                isSpeaking = false  // Completion handler
            }
            isSpeaking = true
        }
    }

    private func toggleRecording() {
        if isRecording {
            evaluator.stopRecording()
            evaluatePronunciation()
            isRecording = false
        } else {
            stopSpeechIfNeeded()  // Stop speech if active
            accuracyMessage = ""
            evaluator.reset()
            evaluator.startRecording()
            isRecording = true
        }
    }

    private func evaluatePronunciation() {
        let accuracy = evaluator.evaluatePronunciation(for: word)
        let percentage = Int(accuracy * 100)
        accuracyMessage = "Accuracy: \(percentage)%"

        switch accuracy {
        case 0.8...1.0:
            points += 10
            ProjectManager.shared.addWord(word, to: "Learned")
            accuracyMessage += "\nExcellent! You've mastered this word."
        case 0.5..<0.8:
            points += 5
            ProjectManager.shared.addWord(word, to: "Practice")
            accuracyMessage += "\nGood job! Keep practicing."
        default:
            points += 1
            ProjectManager.shared.addWord(word, to: "Practice")
            accuracyMessage += "\nKeep trying! You'll get it."
        }
    }

    private func stopSpeechIfNeeded() {
        if isSpeaking {
            speechHelper.stop()
            isSpeaking = false
        }
    }

    private func stopRecordingIfNeeded() {
        if isRecording {
            evaluator.stopRecording()
            isRecording = false
        }
    }

    private func stopAllAudio() {
        stopSpeechIfNeeded()
        stopRecordingIfNeeded()
    }
}

struct WordPopupView_Previews: PreviewProvider {
    static var previews: some View {
        WordPopupView(word: "Example", points: .constant(100))
    }
}
