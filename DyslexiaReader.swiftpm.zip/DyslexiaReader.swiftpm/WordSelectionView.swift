import SwiftUI

struct WordSelectionView: View {
    let recognizedText: String
    @Binding var selectedWord: String
    var onWordSelected: (String) -> Void

    var body: some View {
        let words = recognizedText.components(separatedBy: CharacterSet.whitespacesAndNewlines).filter { !$0.isEmpty }
        
        List(words, id: \.self) { word in
            Button(action: {
                onWordSelected(word)
            }) {
                Text(word)
                    .font(.custom("OpenDyslexic", size: 18))
            }
        }
        .navigationTitle("Select a Word")
    }
}
